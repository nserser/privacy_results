#!/usr/bin/env python3
import argparse,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from scalecert.baseline_fs import package_probe, gaussian_allocation_epsilon


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--out',required=True); ap.add_argument('--deltas',default='1e-3,1e-5'); ap.add_argument('--epsilon-accuracy',type=float,default=-1.0)
    a=ap.parse_args(); inp=pathlib.Path(a.input); out=pathlib.Path(a.out); out.mkdir(parents=True,exist_ok=True); deltas=[float(x) for x in a.deltas.split(',')]
    probe=package_probe(); lock={}; lockp=ROOT/'external/FELDMAN_SHENFELD_RUNTIME_LOCK.json'
    if lockp.exists(): lock=json.loads(lockp.read_text())
    rows=[]
    for p in inp.rglob('*.json'):
        try:r=json.loads(p.read_text())
        except Exception: continue
        if r.get('status')!='OK' or r.get('family')!='bridge_dpsgd': continue
        c=r.get('config',{}); m=r.get('metrics',{})
        if c.get('stage')!='bridges' or int(c.get('b',1))!=1: continue
        z=float(c['noise_multiplier']); M=int(c['M']); k=int(c['k'])
        for delta in deltas:
            try:
                ans=gaussian_allocation_epsilon(delta,z,M,k,1,a.epsilon_accuracy)
                rows.append({'source_experiment_id':r['experiment_id'],'source_family':'bridge_dpsgd','M':M,'k':k,'E':1,'noise_multiplier':z,'eta':float(c['eta']),'delta':delta,**ans})
            except Exception as e:
                rows.append({'source_experiment_id':r.get('experiment_id'),'source_family':'bridge_dpsgd','M':M,'k':k,'E':1,'noise_multiplier':z,'eta':float(c['eta']),'delta':delta,'status':'FAILED','error':repr(e)})
    payload={'probe':probe,'runtime_lock':lock,'rows':rows}; (out/'feldman_shenfeld_baseline.json').write_text(json.dumps(payload,indent=2,sort_keys=True))
    if any(x.get('status')=='FAILED' for x in rows): raise SystemExit(2)
    if not rows: raise SystemExit('no matched b=1 DP-SGD baseline rows')
    print(f'baseline rows={len(rows)}')
if __name__=='__main__': main()
