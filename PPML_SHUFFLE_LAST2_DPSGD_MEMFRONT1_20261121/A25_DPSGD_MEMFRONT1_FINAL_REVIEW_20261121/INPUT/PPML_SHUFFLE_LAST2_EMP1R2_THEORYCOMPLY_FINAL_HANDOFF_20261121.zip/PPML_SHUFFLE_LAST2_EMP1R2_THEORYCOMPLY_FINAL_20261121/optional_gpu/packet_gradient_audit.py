#!/usr/bin/env python3
"""Optional high-dimensional user-packet lower-bound audit.

NOT a formal accountant and excluded from the core SCALECERT GO gate.  The
DP-SGD-like noise is sensitivity-normalized: parameter-noise std per step is
eta * B * z, where z is the conventional one-record noise multiplier.
"""
import argparse, json, math, pathlib
import torch


def common_grad(theta,m,A):
    g=m*theta
    g=g.clone(); g[:,0] += -A*torch.sin(theta[:,0])
    return g


def simulate(n,d,M,k,m,A,B,eta,z,present,device,seed,pattern):
    gen=torch.Generator(device=device); gen.manual_seed(seed)
    theta=torch.randn((n,d),generator=gen,device=device)*0.5
    noise_std=eta*B*z
    # public burn-in
    for _ in range(50):
        theta=theta-eta*common_grad(theta,m,A)+noise_std*torch.randn(theta.shape,generator=gen,device=device)
    # This optional audit uses collision-free k-of-M support, matching the
    # random-allocation comparison rather than the b>1 occupancy stress test.
    supports=[torch.randperm(M,generator=gen,device=device)[:k] for _ in range(n)]
    mask=torch.zeros((n,M),device=device)
    for i,s in enumerate(supports): mask[i,s]=1
    if pattern=='axis0': direction=torch.zeros(d,device=device); direction[0]=1
    elif pattern=='axis1': direction=torch.zeros(d,device=device); direction[min(1,d-1)]=1
    elif pattern=='dense': direction=torch.ones(d,device=device)/math.sqrt(d)
    else: raise ValueError(pattern)
    for t in range(M):
        # sign is immaterial for the distinguishability stress test; magnitude B
        # matches the one-record sensitivity used to define z.
        priv=(B*mask[:,t,None]*direction[None,:]) if present else 0.0
        theta=theta-eta*(common_grad(theta,m,A)+priv)+noise_std*torch.randn(theta.shape,generator=gen,device=device)
    return theta.detach().cpu()


def train_attack(x0,x1,epochs=200):
    X=torch.cat([x0,x1]); y=torch.cat([torch.zeros(len(x0)),torch.ones(len(x1))])
    perm=torch.randperm(len(X)); X=X[perm]; y=y[perm]
    ntr=int(.7*len(X)); Xt,Xv=X[:ntr],X[ntr:]; yt,yv=y[:ntr],y[ntr:]
    mean=Xt.mean(0); std=Xt.std(0).clamp_min(1e-6); Xt=(Xt-mean)/std; Xv=(Xv-mean)/std
    model=torch.nn.Linear(X.shape[1],1); opt=torch.optim.Adam(model.parameters(),lr=.03)
    for _ in range(epochs):
        opt.zero_grad(); loss=torch.nn.functional.binary_cross_entropy_with_logits(model(Xt).squeeze(),yt); loss.backward(); opt.step()
    with torch.no_grad():
        pred=(model(Xv).squeeze()>0).float(); acc=float((pred==yv).float().mean())
    return acc,max(0.0,2*acc-1)


def main():
    ap=argparse.ArgumentParser()
    for name,typ,default in [('n',int,20000),('d',int,32),('M',int,128),('k',int,4),('m',float,.5),('A',float,.55),('B',float,.05),('eta',float,.05),('noise_multiplier',float,2.0)]:
        ap.add_argument('--'+name.replace('_','-'),dest=name,type=typ,default=default)
    ap.add_argument('--pattern',choices=['axis0','axis1','dense'],default='axis0'); ap.add_argument('--seed',type=int,default=20261121); ap.add_argument('--out',required=True); ap.add_argument('--cpu',action='store_true')
    a=ap.parse_args(); device='cpu' if a.cpu or not torch.cuda.is_available() else 'cuda'
    x0=simulate(a.n,a.d,a.M,a.k,a.m,a.A,a.B,a.eta,a.noise_multiplier,False,device,a.seed,a.pattern)
    x1=simulate(a.n,a.d,a.M,a.k,a.m,a.A,a.B,a.eta,a.noise_multiplier,True,device,a.seed+1,a.pattern)
    acc,tv=train_attack(x0,x1)
    out={'device':device,'config':vars(a),'parameter_noise_std':a.eta*a.B*a.noise_multiplier,'test_accuracy':acc,'tv_lower_bound':tv,'status':'AUDIT_LOWER_BOUND_ONLY'}
    pathlib.Path(a.out).write_text(json.dumps(out,indent=2)); print(json.dumps(out,indent=2))
if __name__=='__main__':main()
