# Optional packet-gradient audit

The core one-dimensional synthetic mechanism has exact/numerical likelihood-ratio privacy, which is stronger than an attack lower bound. This optional GPU script is therefore **not** part of the formal SCALECERT decision and remains blocked until `GO_REALISTIC_ULDP_ML`.

It stress-tests a later high-dimensional DP-SGD-like mechanism with a collision-free hidden user packet. Noise is parameterized by the same sensitivity-normalized multiplier `z` used by the core bridge:

`parameter_noise_std = eta * B * z`.

Classifier accuracy provides only an empirical TV lower bound. It must never be reported as a formal privacy guarantee or substituted for the exact/random-allocation accountant.
