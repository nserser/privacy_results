# Experiment stages

## Gaussian

Exact true-occupancy transcript oracle plus deterministic moment-DP final oracle. Includes the `rho=1` no-forgetting control. This stage is an analytic/numerical oracle, not an attack estimate.

## Nonlinear

Hidden-support continuous Langevin results across `M`, actual contribution count `m`, user cap `k`, collision, memory and signal settings. The common absent process is the support-independent quadratic-plus-cosine Langevin witness frozen in the theorem.

Every nonlinear result records the explicit theory certificate:

- `rho_LSI >= m exp(-2|A|)`;
- `gamma` and `lambda` from CONTRACTFIX;
- collision-aware FINITE1 upper bound;
- certified symmetric approximate-DP transfer bound.

## Convergence

Independent numerical axes are varied separately around a fixed reference:

- domain-only enlargement;
- grid-only refinement;
- time-only refinement;
- joint refinement;
- a matrix-exponential (`expm`) temporal reference anchor.

Forward and reverse chi-square, edge mass, and the symmetric privacy profile must remain stable. A combined refinement alone is not sufficient.

## Memory

A single user shock is injected and its final chi-square is measured as a function of age. The horizon is extended adaptively until the privacy impulse tail is negligible; otherwise the job fails closed.

`L_emp` is computed independently from this impulse response. The measured one-shock D2 curve must also lie under the explicit CONTRACTFIX envelope `lambda gamma^r`.

## Multi-epoch

Fresh hidden occupancy is drawn every epoch. The final distribution is propagated recursively. The canonical transcript D2 composes by epoch. The theory-facing collapse uses `gap_D2 * L_emp / (E M)`.

## Stress

Includes:

- finite user-amplitude sweeps;
- fixed-`B` collision sweeps (pure occupancy/collision structure);
- fixed-`G` collision sweeps with `B=G/b` (minibatch-averaged sensitivity semantics);
- known-support versus hidden-support diagnostics;
- metastability/slow-memory settings.

## At-most-k user adjacency

The `usercap` stage explicitly executes every actual contribution count `m=1,...,k` for each declared cap. The empirical user-level curve is the maximum symmetric leakage over those values. The code never assumes that `m=k` is automatically worst-case.

## SGLD bridge

The theorem-consistent discrete update uses noise standard deviation `sqrt(2 eta)`. Decreasing `eta` must converge toward the continuous Langevin reference. This is a theorem-consistency bridge.

## Vanilla DP-SGD extrapolation bridge

The DP-SGD-like update uses a sensitivity-normalized noise multiplier `z`:

`noise_std = eta * B * z`,

so the one-record standardized shift is `1/z`.

This stage is an empirical extrapolation, not a theorem-convergent discretization. Spatial/domain convergence is certified separately using stable symmetric privacy quantities (`TV` and epsilon at target delta), because reverse chi-square can be dominated by probabilities below float64 range.

## Feldman--Shenfeld

Exact matched random-allocation baseline only for `b=1`:

- `num_steps=M`;
- `num_selected=k`;
- `num_epochs=E`;
- Gaussian `sigma=z` for the sensitivity-normalized DP-SGD bridge.

A strict empirical advantage is certified only if the final-state epsilon is below the accountant's **lower** epsilon bound, with a margin, on all pre-registered comparison points.
