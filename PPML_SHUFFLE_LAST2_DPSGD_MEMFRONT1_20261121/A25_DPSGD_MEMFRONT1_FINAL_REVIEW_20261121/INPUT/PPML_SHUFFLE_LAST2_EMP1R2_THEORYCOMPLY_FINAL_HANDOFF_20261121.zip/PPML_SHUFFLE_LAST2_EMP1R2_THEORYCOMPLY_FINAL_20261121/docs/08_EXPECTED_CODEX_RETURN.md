# Expected Codex return

Codex must return one ZIP produced after the staged server run containing:

- all `runs/full/core/*.json` and `runs/full/bridges/*.json`;
- `runs/full/EXPECTED_JOB_MANIFEST.json`;
- `runs/full/baseline/feldman_shenfeld_baseline.json`;
- `external/FELDMAN_SHENFELD_RUNTIME_LOCK.json` with the exact external Git commit;
- `runs/full/summary/all_results.csv`;
- `runs/full/summary/scaling_fits.csv`;
- `runs/full/summary/checks.json`;
- `runs/full/summary/decision.json`;
- `runs/full/summary/FINAL_SCALECERT_REPORT.md`;
- `runs/full/figures/`;
- `runs/full/pip_freeze.txt` and `runs/full/environment.json`;
- all SLURM logs;
- every failed or numerically-invalid record without deletion;
- `IMPLEMENTATION_VERIFICATION.json` and `PROVENANCE.json`.

The frozen `configs/full_staged.yaml` currently expands to **336 expected scientific jobs**. The manifest generated at runtime is authoritative; Codex must not manually add/remove jobs.

The final scientific interpretation must be based on `decision.json` and the complete gate evidence in `checks.json`, not on individual favorable plots.
