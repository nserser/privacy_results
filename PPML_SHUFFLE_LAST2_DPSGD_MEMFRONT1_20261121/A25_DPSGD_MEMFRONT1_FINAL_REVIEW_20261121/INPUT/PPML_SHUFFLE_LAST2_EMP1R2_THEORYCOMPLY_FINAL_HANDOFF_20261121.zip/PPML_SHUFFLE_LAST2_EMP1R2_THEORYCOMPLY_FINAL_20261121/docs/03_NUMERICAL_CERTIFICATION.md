# Numerical certification

## Continuous reference

A Chang–Cooper conservative finite-volume generator is used on a reflecting finite domain. No probability is renormalized by the interval transition.

The reflecting finite domain approximates the unbounded process only when:

- stationary/final edge mass is tiny;
- enlarging the domain does not materially change leakage;
- refining the grid does not materially change leakage;
- increasing backward-Euler interval substeps does not materially change leakage;
- fitted scaling exponents are stable.

Default headline gate:

- top-two leakage relative change <= 2%;
- top-two exponent change <= 0.05;
- edge mass <= 1e-5.

## Discrete bridges

Discrete Gaussian transition matrices integrate the Gaussian probability over finite grid cells. Probability outside the domain is tracked as `escaped_mass`; no step renormalizes it.

A bridge run is `NUMERICAL_INVALID` if escaped mass exceeds its configured tolerance.

The retained finite-grid distributions are normalized only after the lost mass is recorded. The lost/truncated mass is then treated as a TV approximation defect. The symmetric hockey-stick profile is conservatively inflated using

`H_a(P,Q) <= H_a(P_tilde,Q_tilde) + tau_P + a tau_Q`

and the reverse analogue. The epsilon used for the external baseline is the defect-adjusted **upper** epsilon, not the optimistic normalized-grid epsilon.

## Tail privacy

Continuous final chi-square and privacy profiles are computed only from probability vectors whose mass passes the explicit tolerance, and all positive Chang--Cooper tail mass is retained. The package does not silently floor positive reference tails.

For the discrete DP-SGD bridge, extreme reverse-Renyi tails may still be below float64 range; the practical bridge gate therefore uses the defect-adjusted symmetric privacy profile/epsilon rather than treating non-finite reverse chi-square as a scientific failure.
