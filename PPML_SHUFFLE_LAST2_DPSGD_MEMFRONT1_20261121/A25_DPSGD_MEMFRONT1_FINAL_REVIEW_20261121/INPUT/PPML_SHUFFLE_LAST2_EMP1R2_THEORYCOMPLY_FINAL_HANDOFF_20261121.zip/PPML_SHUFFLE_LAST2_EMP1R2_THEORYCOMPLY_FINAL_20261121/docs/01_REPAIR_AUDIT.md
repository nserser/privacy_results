# Repair audit relative to Codex review package

The Codex review correctly stopped the earlier handoff because mandatory stages were absent and boundary loss could be hidden by normalization.

An additional implementation defect was found during manual review: the original hidden-support dynamic program normalized every latent `records remaining` branch to probability one after each batch. Those branches are sub-probability densities whose integrals are the probabilities of their latent occupancy states. Independent normalization destroys the hidden-support mixture.

This implementation fixes that defect and includes a regression test comparing hidden-support DP against exhaustive occupancy enumeration.

The prior smoke nonlinear values are therefore not scientific evidence and must not be compared numerically with the repaired outputs.
