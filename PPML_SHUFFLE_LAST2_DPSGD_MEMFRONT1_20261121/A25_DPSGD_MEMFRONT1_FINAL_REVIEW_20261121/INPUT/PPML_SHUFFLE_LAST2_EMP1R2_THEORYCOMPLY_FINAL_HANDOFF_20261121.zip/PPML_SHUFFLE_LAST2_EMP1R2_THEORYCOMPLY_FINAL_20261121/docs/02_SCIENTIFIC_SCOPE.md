# Scientific scope

The core claim tested by SCALECERT is not merely that final state privacy can be better than transcript privacy. The distinctive prediction is a **growing scaling separation** caused by finite privacy memory combined with hidden random user support.

Target behavior:

- canonical transcript: approximately `Theta(M^-1)`;
- final state in the certified finite-memory family: approximately `Theta(M^-2)`;
- ratio: approximately `M/L_emp`;
- fresh multi-epoch ratio: approximately `E M/L_emp` while final leakage saturates.

The nonlinear certified family is

`U(x)=m*x^2/2 + A*cos(x)`, with `A>m>0`,

and a bounded user drift `B*C_t` at the hidden occupied batches.

The continuous result does **not** prove the same behavior for arbitrary vanilla DP-SGD. That is why the discrete DP-SGD bridge is an explicit extrapolation gate.
