# Feldman--Shenfeld baseline

Repository: `https://github.com/moshenfeld/PLD_accounting`

The public repository documents the stable paper branches `PLD-paper` and `MS-FFT-paper` and the Gaussian random-allocation API `gaussian_allocation_epsilon_range`.

## Runtime pinning

The install script checks out `MS-FFT-paper`, records the exact resolved commit in `external/FELDMAN_SHENFELD_RUNTIME_LOCK.json`, installs that checkout, discovers the live API signature, and executes a smoke query. The first successful server installation creates the lock; subsequent executions reuse the detached recorded revision.

The handoff intentionally does not invent a commit hash without network access.

## Matched model

The principal exact comparison uses the collision-free `b=1` DP-SGD bridge:

- `num_steps=M`;
- `num_selected=k`;
- `num_epochs=1` for the SCALECERT bridge comparison;
- Gaussian `sigma=z`, where `z` is the sensitivity-normalized noise multiplier.

Collision experiments with `b>1` are **not** described as exact Feldman--Shenfeld matches.

## Lower versus upper epsilon bounds

The accountant can return an epsilon interval. The adapter preserves both:

- `epsilon_lower` — optimistic/lower bound on the allocation mechanism's epsilon;
- `epsilon_upper` — pessimistic/upper bound.

A strict final-state advantage is certified only when

`final_epsilon < 0.99 * epsilon_lower`.

Using only `epsilon_upper` to claim separation is forbidden: the true allocation epsilon could be smaller than our final-state epsilon even though our value lies below the upper bound.

Both target deltas (`1e-3`, `1e-5`) and both pre-registered user-level DP-SGD lines (`k=2, eta=0.1, z=2` and `z=4`) must pass at the largest registered `M` values.
