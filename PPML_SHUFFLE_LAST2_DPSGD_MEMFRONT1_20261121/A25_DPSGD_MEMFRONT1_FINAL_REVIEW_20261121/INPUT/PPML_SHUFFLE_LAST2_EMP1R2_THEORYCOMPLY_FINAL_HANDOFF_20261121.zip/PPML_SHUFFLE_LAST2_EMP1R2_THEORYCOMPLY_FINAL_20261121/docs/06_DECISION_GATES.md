# Decision gates

The aggregation script is fail-closed. A missing result, duplicate result, extra/stale result, non-OK mandatory job, or expected-manifest mismatch blocks scientific certification.

## Continuous theorem-family gates

A realistic user-level ML GO requires all of the following:

- main nonlinear forward **and reverse** final exponents > 1.7 with good log-log fit;
- matched transcript exponent in `[0.8,1.2]`;
- independent domain/grid/time convergence and joint/expm anchor agreement;
- finite continuous edge mass and reverse privacy;
- all FINITE1/profile certificates valid;
- one-shock contraction envelope valid and adaptive memory tail complete;
- chi-square memory collapse `gap_chi2 * L_emp / M` stable across several memory settings;
- multi-epoch normalized collapse and final-state saturation behavior;
- at-most-`k` adjacency sweep complete and worst-case symmetric leakage still growing faster than `M^-1`;
- bounded-`k`, finite-amplitude, fixed-`B` collision, fixed-`G` collision, known/hidden-support, metastability and no-forgetting controls consistent with the frozen theory;
- SGLD bridge converging toward the continuous reference.

## DP-SGD extrapolation gate

A single favorable point can never trigger a GO.

The pre-registered user-level lines are:

- `k=2, eta=0.1, z=2`;
- `k=2, eta=0.1, z=4`.

Both must:

- contain at least three `M` values;
- pass discrete grid/domain convergence;
- have a stable symmetric-TV decay exponent > 0.55 with `R^2 > 0.95`;
- retain a transcript chi-square exponent near 1.

The full grid contains additional `k, eta, z` values for phase-map interpretation, but they cannot substitute for either required line.

## Feldman--Shenfeld gate

For each required DP-SGD line and each target delta `1e-3` and `1e-5`, use the exactly matched `b=1` random-allocation accountant.

A strict advantage requires:

`final_epsilon < 0.99 * FS_epsilon_lower`.

Comparing only to the Feldman--Shenfeld upper bound is forbidden because that could produce a false-positive separation.

At least the three largest registered `M` values on each required line must satisfy the strict lower-bound separation.

## Decisions

- `GO_REALISTIC_ULDP_ML`: every theorem/numerical/user-level/DP-SGD/baseline gate passes.
- `REPAIR_SCALECERT`: the core theory remains viable but a numerical/baseline/compliance gate is unresolved or fails in a repairable way.
- `STOP_REALISTIC_DP_SGD`: the continuous theory is certified but the pre-registered practical DP-SGD bridge does not show the required robust growing advantage.
- `FAIL_NUMERICAL_VALIDATION`: mandatory jobs are missing/failed/invalid or the expected-job manifest is inconsistent.
