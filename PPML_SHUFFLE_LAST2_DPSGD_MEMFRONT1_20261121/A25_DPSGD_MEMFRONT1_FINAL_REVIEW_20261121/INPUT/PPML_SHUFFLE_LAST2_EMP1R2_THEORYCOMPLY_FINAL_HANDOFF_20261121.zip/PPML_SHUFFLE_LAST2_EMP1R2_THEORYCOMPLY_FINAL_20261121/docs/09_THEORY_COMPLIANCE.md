# 09 — Theory Compliance Matrix

## Frozen theorem to implementation bindings

| Theoretical object | Implementation binding |
|---|---|
| user occupancy `C` | exact multivariate-hypergeometric latent DP |
| hidden support mixture | sub-probability branch masses; no branch normalization |
| support-independent absent process | common quadratic-plus-cosine Langevin reference |
| stationary reference | exact zero-flux Chang--Cooper stationary vector |
| `rho_LSI >= m exp(-2|A|)` | `theory_certificate.lsi_rho_lower` |
| `gamma, lambda` CONTRACTFIX recurrence | `contraction_constants` |
| finite-amplitude collision-aware bound | `finite1_chi2_upper` |
| one-shock forgetting envelope | adaptive memory stage + `one_shock_d2_envelope` |
| symmetric DP | forward/reverse chi-square + exact grid privacy profile + certified transfer envelope |
| at-most-`k` adjacency | explicit `m=1..k` user-cap stage and empirical max |
| `M/L_priv` | chi-square transcript/final ratio times independent `L_emp/M` |
| `EM/L_priv` | multi-epoch D2 ratio times independent `L_emp/(EM)` |
| no-forgetting boundary | exact Gaussian `rho=1` control |
| numerical continuum reference | independent domain/grid/time refinements + joint/expm anchor |
| SGLD theorem bridge | theorem-consistent `sqrt(2 eta)` noise and eta convergence |
| vanilla DP-SGD extrapolation | sensitivity-normalized `z`; no theorem claim |
| allocation-only baseline | Feldman--Shenfeld `b=1`, `num_steps=M`, `num_selected=k` |

## Important scope boundary

"True occupancy" refers to the protected user's fixed-capacity slots under uniform reshuffling. The theorem requires the common absent-user process to remain support-independent. The package therefore does **not** claim that ordinary heterogeneous pooled-data random reshuffling is already covered.

## Numerical tail policy

Continuous solver: all positive cell masses are preserved; only negative roundoff below a strict tolerance may be clipped.

Discrete bridge: finite-domain and Gaussian-stencil loss is explicitly carried as lost mass. Headline bridge comparisons use stable `(epsilon,delta)` quantities because reverse chi-square can be dominated by probabilities below float64 range.
