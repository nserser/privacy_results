# Multi-CPU execution policy

Multi-CPU execution is required whenever it preserves mathematical and numerical semantics.

## Parallelize across independent jobs

Use process-level CPU parallelism for:

- independent parameter configurations;
- convergence variants;
- user-cap values;
- SGLD/DP-SGD bridge settings;
- independent SLURM stages/shards.

Every process receives one BLAS/OpenMP thread:

```bash
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
```

Do not alter a deterministic solver or change floating-point reduction order merely to use more cores inside one job.

## Mandatory equivalence check

`verify_implementation.sh` executes a representative deterministic equivalence plan with one worker and four workers. The scientific fields must match exactly. The larger theory-compliance smoke plan is then executed once with four workers.

The full server run may use all CPUs allocated by SLURM because jobs are independent and experiment IDs/configurations are deterministic.
