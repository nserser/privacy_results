# Handoff index — THEORYCOMPLY

- `README.md` — setup, scope and execution entry point.
- `CODEX_MASTER_PROMPT.md` — exact execution instructions for Codex.
- `IMPLEMENTATION_VERIFICATION.json` — local theorem-compliance unit/smoke/worker verification.
- `LOCAL_THEORY_COMPLIANCE_VALIDATION.json` — concise local evidence from the verified smoke implementation.
- `PROVENANCE.json` — source review package hash and external-baseline pinning policy.
- `docs/` — audit, scientific scope, numerical certification, stages, CPU policy, decision gates, baseline semantics, expected return and theory-compliance matrix.
- `src/scalecert/` — theorem-compliant implementation.
- `tests/` — regression/invariant tests, including hidden-mixture, reverse-tail, stationary-reference and theorem-certificate checks.
- `configs/equivalence.yaml` — 1-vs-4-worker exact equivalence suite.
- `configs/smoke.yaml` — mandatory local/server implementation smoke plan.
- `configs/full_staged.yaml` — frozen server plan (**336 expected scientific jobs** at this revision).
- `scripts/build_expected_manifest.py` — authoritative expected-job manifest generator.
- `scripts/` — runners, aggregation, baseline adapter, plotting, verification and result packaging.
- `slurm/` — CPU core/bridge/baseline/final pipeline scripts and GPU gate.
- `optional_gpu/` — later non-formal packet-gradient lower-bound audit, blocked until final GO.
