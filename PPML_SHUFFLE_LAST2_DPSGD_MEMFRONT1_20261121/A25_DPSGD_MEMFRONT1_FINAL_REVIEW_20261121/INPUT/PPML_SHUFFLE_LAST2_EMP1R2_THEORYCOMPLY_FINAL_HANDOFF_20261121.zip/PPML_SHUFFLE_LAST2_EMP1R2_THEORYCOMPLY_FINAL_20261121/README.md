# PPML-SHUFFLE-LAST2-EMP1R2-THEORYCOMPLY — Final Theory-Compliant SCALECERT Implementation

This package is the final CPU-first implementation handoff for:

**PPML-SHUFFLE-LAST2-EMP1R2-THEORYCOMPLY — User-Level Hidden-State Scaling Certification.**

It supersedes all earlier SCALECERT handoffs.

## Theory-compliance changes

The implementation now enforces the frozen theoretical model rather than only reproducing the qualitative scaling:

1. **Positive probability tails are preserved.** The Chang--Cooper solver never zeros small positive masses; reverse privacy is mandatory.
2. **Exact numerical stationary initialization.** The reference law is the exact zero-flux stationary vector of the Chang--Cooper generator; the analytic Gibbs law is retained as a convergence diagnostic.
3. **Independent numerical convergence axes.** Domain, spatial grid, temporal step, joint refinement, and an `expm` temporal reference anchor are separate experiments.
4. **Symmetric privacy.** Forward/reverse chi-square and the symmetric privacy profile are evaluated; reverse finiteness/convergence is a gate.
5. **At-most-k user adjacency.** Dedicated jobs evaluate every actual contribution count `m=1,...,k` and certify the worst empirical privacy curve rather than assuming `m=k`.
6. **Explicit CONTRACTFIX/FINITE1 certificate.** Each nonlinear run records `rho_LSI`, `gamma`, `lambda`, `L_FA`, and the collision-aware finite-amplitude chi-square upper bound; observed forward leakage and the symmetric privacy profile must lie below the certified envelope.
7. **One-shock theorem check.** The measured impulse response must satisfy the theoretical `D2(r) <= lambda gamma^r` envelope.
8. **Chi-square memory collapse.** `M/L_emp` validation uses the theorem's chi-square ratio; multi-epoch uses the compositional D2 normalization.
9. **Adaptive memory horizon.** The impulse response is extended until its tail is demonstrably negligible, or the run fails closed.
10. **DP-SGD noise multiplier.** `noise_multiplier=z` is sensitivity-normalized: parameter noise std is `eta * B * z`, hence one-record standardized signal is `1/z`.
11. **Discrete numerical certification.** DP-SGD bridge grid/domain convergence is checked using stable symmetric `(epsilon,delta)` quantities. Finite-domain/stencil loss is tracked as a TV defect and charged into a conservative privacy-profile/epsilon upper estimate rather than ignored after normalization.
12. **Two collision semantics.** Fixed-`B` tests isolate occupancy structure; fixed-`G` tests set `B=G/b` to reflect minibatch averaging.
13. **Feldman--Shenfeld lower-bound separation.** A GO requires our final epsilon to be strictly below the accountant's *lower* epsilon bound, not merely below its upper bound, on two pre-registered user-level parameter lines and both target deltas.
14. **Expected-job manifest.** Missing, duplicate, extra, stale, failed, or numerically invalid mandatory jobs block certification.
15. **Robust GO.** A single favorable configuration can never trigger realistic user-level ML.

## Scope

The certified nonlinear theorem concerns a fixed-capacity **random-support user overlay on a support-independent common Langevin base process**. It does not claim the same theorem for arbitrary heterogeneous pooled-data reshuffling.

The vanilla DP-SGD stage is explicitly an **extrapolation bridge**, not a theorem-convergent Euler discretization.

## GPU policy

No GPU is needed for SCALECERT. GPU/user-level realistic ML stays blocked unless the final decision is exactly:

`GO_REALISTIC_ULDP_ML`.

## Local implementation verification

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-core.txt
./scripts/verify_implementation.sh
```

This runs:
- 22 unit/regression tests;
- a 1-worker vs 4-worker exact scientific-equivalence suite;
- the full theory-compliance smoke plan;
- expected-job-manifest validation;
- fail-closed aggregation.

See `IMPLEMENTATION_VERIFICATION.json`.

## Server execution

```bash
source .venv/bin/activate
export PYTHONPATH="$PWD/src"
./scripts/verify_implementation.sh
bash slurm/submit_pipeline.sh
```

The pipeline runs core and bridge stages in parallel, pins and runs the external Feldman--Shenfeld accountant, then performs final aggregation.

## Manual final aggregation

```bash
python scripts/build_expected_manifest.py \
  --config configs/full_staged.yaml \
  --out runs/full/EXPECTED_JOB_MANIFEST.json

python scripts/aggregate.py \
  --input runs/full \
  --baseline runs/full/baseline/feldman_shenfeld_baseline.json \
  --out runs/full/summary \
  --config configs/full_staged.yaml
```

Valid decisions:
- `GO_REALISTIC_ULDP_ML`
- `REPAIR_SCALECERT`
- `STOP_REALISTIC_DP_SGD`
- `FAIL_NUMERICAL_VALIDATION`
