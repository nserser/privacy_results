#!/usr/bin/env bash
#SBATCH --job-name=scalecert_fs
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=04:00:00
#SBATCH --output=logs/baseline_%j.out
#SBATCH --error=logs/baseline_%j.err
set -euo pipefail
ROOT="${SLURM_SUBMIT_DIR:-$PWD}"; cd "$ROOT"
export PYTHONPATH="$ROOT/src"
source .venv/bin/activate
mkdir -p runs/full/baseline logs
./scripts/install_feldman_shenfeld.sh
python scripts/run_feldman_baseline.py --input runs/full --out runs/full/baseline --deltas 1e-3,1e-5
