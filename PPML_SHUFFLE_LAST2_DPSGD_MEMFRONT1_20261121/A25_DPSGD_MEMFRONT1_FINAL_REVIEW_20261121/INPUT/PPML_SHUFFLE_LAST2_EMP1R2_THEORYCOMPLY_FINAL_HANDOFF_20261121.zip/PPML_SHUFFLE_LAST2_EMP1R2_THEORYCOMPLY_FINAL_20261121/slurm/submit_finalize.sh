#!/usr/bin/env bash
#SBATCH --job-name=scalecert_final
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=01:00:00
#SBATCH --output=logs/final_%j.out
#SBATCH --error=logs/final_%j.err
set -euo pipefail
ROOT="${SLURM_SUBMIT_DIR:-$PWD}"; cd "$ROOT"
export PYTHONPATH="$ROOT/src"; source .venv/bin/activate
mkdir -p runs/full/summary runs/full/figures logs
python scripts/build_expected_manifest.py --config configs/full_staged.yaml --out runs/full/EXPECTED_JOB_MANIFEST.json
python scripts/aggregate.py --input runs/full --baseline runs/full/baseline/feldman_shenfeld_baseline.json --out runs/full/summary --config configs/full_staged.yaml
python scripts/plot_report.py --summary runs/full/summary --out runs/full/figures
python -m pip freeze > runs/full/pip_freeze.txt
python - <<'PY'
import json,platform,os,pathlib
pathlib.Path('runs/full/environment.json').write_text(json.dumps({'python':platform.python_version(),'platform':platform.platform(),'slurm_job_id':os.environ.get('SLURM_JOB_ID')},indent=2))
PY
