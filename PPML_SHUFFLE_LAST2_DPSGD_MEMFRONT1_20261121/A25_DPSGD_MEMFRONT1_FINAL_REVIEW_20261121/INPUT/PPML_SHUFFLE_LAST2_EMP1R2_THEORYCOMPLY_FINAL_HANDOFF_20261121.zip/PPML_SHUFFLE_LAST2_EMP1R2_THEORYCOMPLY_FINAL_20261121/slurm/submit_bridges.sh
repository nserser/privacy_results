#!/usr/bin/env bash
#SBATCH --job-name=scalecert_bridges
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=16
#SBATCH --mem=64G
#SBATCH --time=24:00:00
#SBATCH --output=logs/bridges_%j.out
#SBATCH --error=logs/bridges_%j.err
set -euo pipefail
ROOT="${SLURM_SUBMIT_DIR:-$PWD}"; cd "$ROOT"
export PYTHONPATH="$ROOT/src" PYTHONHASHSEED=0
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
source .venv/bin/activate
mkdir -p runs/full/bridges logs
python scripts/run_plan.py --config configs/full_staged.yaml --out runs/full/bridges --workers "${SLURM_CPUS_PER_TASK}" --stages bridges,bridge_convergence
