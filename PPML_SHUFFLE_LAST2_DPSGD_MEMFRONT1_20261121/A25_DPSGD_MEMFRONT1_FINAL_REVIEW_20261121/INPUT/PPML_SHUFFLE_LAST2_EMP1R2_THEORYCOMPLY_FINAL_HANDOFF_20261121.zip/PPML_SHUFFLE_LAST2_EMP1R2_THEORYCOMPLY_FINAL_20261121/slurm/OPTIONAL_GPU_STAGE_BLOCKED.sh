#!/usr/bin/env bash
set -euo pipefail
DECISION="${1:-runs/full/summary/decision.json}"
python - "$DECISION" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]))
if x.get('decision')!='GO_REALISTIC_ULDP_ML':
    raise SystemExit('GPU stage BLOCKED: SCALECERT has not returned GO_REALISTIC_ULDP_ML')
print('GO gate present. Begin the separately specified realistic user-level ML milestone.')
PY
