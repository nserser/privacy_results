#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
source .venv/bin/activate; export PYTHONPATH="$ROOT/src"
./scripts/verify_implementation.sh
mkdir -p runs
python scripts/build_expected_manifest.py --config configs/full_staged.yaml --out runs/EXPECTED_JOB_MANIFEST.json
CORE=$(sbatch --parsable slurm/submit_core.sh)
BRIDGE=$(sbatch --parsable slurm/submit_bridges.sh)
BASE=$(sbatch --parsable --dependency="afterok:${CORE}:${BRIDGE}" slurm/submit_baseline.sh)
FINAL=$(sbatch --parsable --dependency="afterok:${BASE}" slurm/submit_finalize.sh)
printf 'core=%s\nbridges=%s\nbaseline=%s\nfinal=%s\n' "$CORE" "$BRIDGE" "$BASE" "$FINAL" | tee runs/SLURM_PIPELINE_IDS.txt
