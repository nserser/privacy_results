# External baseline policy

The handoff does not vendor third-party source code.

Run `scripts/install_feldman_shenfeld.sh` on the execution server. On first run it:

1. clones `https://github.com/moshenfeld/PLD_accounting`;
2. resolves the stable `MS-FFT-paper` branch;
3. writes the exact commit to `FELDMAN_SHENFELD_RUNTIME_LOCK.json`;
4. installs that checkout;
5. executes an API smoke query.

If the lock already exists, subsequent runs check out that exact commit rather than a moving branch.

The baseline is declared exact only for collision-free `b=1` random allocation.
