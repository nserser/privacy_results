# Codex Master Prompt — PPML-SHUFFLE-LAST2-EMP1R2-THEORYCOMPLY

Execute this package exactly as specified. Do not redesign the mechanism, loosen a gate, discard an inconvenient tail, or reinterpret a failed job.

## Mandatory order

1. Read `README.md` and every `docs/*.md` file.
2. Create/activate a clean Python environment and install `requirements-core.txt`.
3. Run `./scripts/verify_implementation.sh`. Stop immediately on failure.
4. Generate the full expected-job manifest from `configs/full_staged.yaml`.
5. Submit CPU core stages: `gaussian, nonlinear, convergence, memory, multiepoch, stress, usercap`.
6. Submit CPU bridge stages: `bridges, bridge_convergence`.
7. Install/pin Feldman--Shenfeld using `scripts/install_feldman_shenfeld.sh`; preserve `external/FELDMAN_SHENFELD_RUNTIME_LOCK.json`.
8. Run `scripts/run_feldman_baseline.py` on the completed `b=1` DP-SGD bridge results.
9. Run final aggregation with `--config configs/full_staged.yaml` and the baseline JSON.
10. Package the complete `runs/full/`, logs, environment metadata, runtime lock, expected manifest, and reports.
11. Never start the optional GPU stage unless `summary/decision.json` is exactly `GO_REALISTIC_ULDP_ML`.

## Multi-CPU requirement

Independent jobs must use process-level CPU parallelism whenever correctness is unchanged. Keep numerical-library thread count at one per worker:

```bash
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
export OPENBLAS_NUM_THREADS=1
export NUMEXPR_NUM_THREADS=1
```

Do not change the internal deterministic solver merely to make one job parallel. The package already verifies exact 1-worker/4-worker equivalence on a representative suite.

## Scientific invariants

- Hidden occupancy branches are sub-probability masses and must never be independently normalized.
- Never hard-zero small positive continuous tail probabilities.
- The reference continuous law is `numerical_stationary_mass()`, not an ad-hoc normalized analytic sample.
- Reverse chi-square and the symmetric privacy profile are mandatory for the continuous theorem family.
- User-level adjacency means the empirical maximum over every actual `m <= k` in the dedicated cap sweep.
- Do not bypass a FINITE1 or one-shock theory-certificate failure.
- Do not truncate the memory impulse response before its tail certificate passes.
- Fixed-`B` and fixed-`G` collision experiments answer different questions; report both separately.
- `noise_multiplier` is dimensionless and sensitivity-normalized; do not replace it with an absolute gradient-noise standard deviation.
- DP-SGD bridge chi-square can be tail-unstable in finite precision; the bridge's numerical convergence and Feldman comparison use the symmetric privacy profile / epsilon at target delta.
- Feldman--Shenfeld is exact only for the declared collision-free `b=1` random-allocation comparison.
- A strict empirical advantage requires `final_epsilon < 0.99 * FS_epsilon_lower`. Comparing with the FS upper bound is forbidden.
- Missing/duplicate/extra results are certification failures.
- A single good DP-SGD point is insufficient. The pre-registered `k=2, eta=0.1, z=2` and `k=2, eta=0.1, z=4` lines must both pass numerical/scaling and Feldman gates at both deltas.

## Required return

Return one ZIP containing the entire `runs/full/` tree, `logs/`, `IMPLEMENTATION_VERIFICATION.json`, Feldman runtime lock, exact Git commit, package versions, SLURM IDs, CPU metadata, all failed records unchanged, and the final summary/figures.
