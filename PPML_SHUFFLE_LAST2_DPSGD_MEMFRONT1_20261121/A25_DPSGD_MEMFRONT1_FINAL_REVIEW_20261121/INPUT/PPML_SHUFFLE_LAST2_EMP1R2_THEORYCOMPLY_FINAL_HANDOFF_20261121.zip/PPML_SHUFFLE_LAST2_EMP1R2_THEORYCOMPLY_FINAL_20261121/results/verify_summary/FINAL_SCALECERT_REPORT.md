# SCALECERT Theory-Compliant Aggregate Report

**Decision:** `REPAIR_SCALECERT`
**Reason:** one or more theory/numerical compliance gates failed

## Gate summary
- expected_manifest: PASS
- convergence: PASS
- main_scaling: PASS
- theory_certificates: PASS
- k_packet: FAIL
- at_most_k_adjacency: PASS
- collision_stress: FAIL
- finite_amplitude: FAIL
- known_vs_hidden_support: PASS
- no_forgetting: PASS
- memory_collapse: PASS
- metastability: PASS
- multi_epoch: PASS
- sgld_bridge: PASS
- dpsgd_numerical_convergence: PASS
- dpsgd_bridge: FAIL
- feldman_shenfeld: FAIL

See `checks.json`, `scaling_fits.csv`, `all_results.csv`, and the exact expected-job manifest for inspectable evidence.
