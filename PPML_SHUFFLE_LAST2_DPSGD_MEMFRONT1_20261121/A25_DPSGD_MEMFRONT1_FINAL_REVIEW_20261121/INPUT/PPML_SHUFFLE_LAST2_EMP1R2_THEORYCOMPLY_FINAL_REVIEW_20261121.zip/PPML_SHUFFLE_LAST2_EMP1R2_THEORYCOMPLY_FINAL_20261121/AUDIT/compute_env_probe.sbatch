#!/usr/bin/env bash
#SBATCH --job-name=scalecert_envprobe
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --time=00:02:00
#SBATCH --output=logs/envprobe_%j.out
#SBATCH --error=logs/envprobe_%j.err
set -eu
hostname
python3 - <<'PY'
import sys
print(sys.version)
for m in ['numpy','scipy','pandas','yaml','matplotlib','pytest']:
 try:
  x=__import__(m); print(m,getattr(x,'__version__','ok'))
 except Exception as e: print(m,'MISSING',type(e).__name__,str(e))
PY
