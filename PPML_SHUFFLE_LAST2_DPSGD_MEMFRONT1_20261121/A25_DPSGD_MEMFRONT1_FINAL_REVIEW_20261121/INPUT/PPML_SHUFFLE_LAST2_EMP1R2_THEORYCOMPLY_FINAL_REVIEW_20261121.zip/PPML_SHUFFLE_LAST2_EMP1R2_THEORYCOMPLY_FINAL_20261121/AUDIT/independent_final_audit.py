#!/usr/bin/env python3
"""Independent, read-only audit of the completed SCALECERT execution."""
from __future__ import annotations
import csv, hashlib, json, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks={}
manifest=json.loads((ROOT/'runs/full/EXPECTED_JOB_MANIFEST.json').read_text())
rows=manifest['rows']; checks['manifest_count_336']=len(rows)==manifest['count']==336
expected={}
for r in rows:
    folder='bridges' if r['stage'] in ('bridges','bridge_convergence') else 'core'
    name=f"{r['family']}_{r['experiment_id']}.json"
    expected[(folder,name)]=r
actual={}
for folder in ('core','bridges'):
    for p in (ROOT/'runs/full'/folder).glob('*.json'):
        actual[(folder,p.name)]=p
checks['exact_core_bridge_file_set']=set(actual)==set(expected)
status_ok=True
for key,r in expected.items():
    p=actual.get(key)
    if p is None:
        status_ok=False; continue
    try: x=json.loads(p.read_text())
    except Exception: status_ok=False; continue
    if x.get('status')!='OK' or x.get('experiment_id')!=r['experiment_id'] or x.get('family')!=r['family']:
        status_ok=False
    if x.get('config',{}).get('stage')!=r['stage']:
        status_ok=False
checks['all_336_rows_ok_and_match_config']=status_ok
checks['core_rows_210']=sum(1 for x in rows if x['stage'] not in ('bridges','bridge_convergence'))==210
checks['bridge_rows_126']=sum(1 for x in rows if x['stage'] in ('bridges','bridge_convergence'))==126
with (ROOT/'runs/full/summary/all_results.csv').open(newline='') as f: result_rows=list(csv.DictReader(f))
checks['summary_rows_336_ok']=len(result_rows)==336 and all(x.get('status')=='OK' for x in result_rows)
summary=json.loads((ROOT/'runs/full/summary/checks.json').read_text())
decision=json.loads((ROOT/'runs/full/summary/decision.json').read_text())
checks['aggregation_has_zero_failed_records']=decision.get('failed_records')==0
checks['terminal_decision_stop_dpsgd']=decision.get('decision')=='STOP_REALISTIC_DP_SGD'
checks['only_preregistered_dpsgd_bridge_gate_fails']=all(v.get('pass') is True for k,v in summary.items() if k != 'dpsgd_bridge') and summary.get('dpsgd_bridge',{}).get('pass') is False
checks['feldman_shenfeld_gate_pass']=summary.get('feldman_shenfeld',{}).get('pass') is True
base=json.loads((ROOT/'runs/full/baseline/feldman_shenfeld_baseline.json').read_text())
brows=base['rows']; keyset={(x['source_experiment_id'],float(x['delta'])) for x in brows}
checks['feldman_rows_144']=len(brows)==144 and len(keyset)==144
checks['feldman_rows_no_failures']=not any(x.get('status')=='FAILED' for x in brows)
checks['feldman_bounds_ordered']=all(float(x['epsilon_lower'])<=float(x['epsilon_upper']) for x in brows)
checks['feldman_runtime_commit_matches_lock']=base['runtime_lock']==json.loads((ROOT/'external/FELDMAN_SHENFELD_RUNTIME_LOCK.json').read_text())
progress=ROOT/'runs/full/baseline/feldman_shenfeld_progress.jsonl'
pr=[json.loads(x) for x in progress.read_text().splitlines() if x.strip()]
checks['feldman_progress_144_ok']=len(pr)==144 and all(x['status']=='OK' for x in pr) and [x['completed'] for x in pr]==list(range(1,145))
unit=json.loads((ROOT/'IMPLEMENTATION_VERIFICATION.json').read_text())
checks['implementation_verification_pass']=unit.get('status')=='THEORY_COMPLIANCE_IMPLEMENTATION_VERIFIED' and unit.get('unit_tests')=='PASS' and unit.get('worker_equivalence')=='EXACT'
eq=json.loads((ROOT/'AUDIT/FS_EQUIV/WORKER_EQUIVALENCE.json').read_text())
checks['baseline_wrapper_parallel_equivalence']=eq.get('status')=='PASS' and eq.get('values_exact') is True
checks['final_report_exists']= (ROOT/'runs/full/summary/FINAL_SCALECERT_REPORT.md').is_file()
checks['figures_present']=len(list((ROOT/'runs/full/figures').glob('*.png')))>=5
# SLURM accounting includes the canceled serial attempt and successful replacement.
acct=subprocess.run(['sacct','-j','900,901,902,903,904,905,906','--format=JobID,State,ExitCode,Elapsed','-P'],capture_output=True,text=True,check=True).stdout
(ROOT/'AUDIT/SLURM_ACCOUNTING.txt').write_text(acct)
state={}
for line in acct.splitlines()[1:]:
 parts=line.split('|')
 if len(parts)>=4 and '.' not in parts[0]: state[parts[0]]=(parts[1],parts[2])
checks['core_and_bridges_completed'] = state.get('900',('',))[0]=='COMPLETED' and state.get('901',('',))[0]=='COMPLETED'
checks['parallel_baseline_and_final_completed'] = state.get('904',('',))[0]=='COMPLETED' and state.get('905',('',))[0]=='COMPLETED'
checks['serial_attempt_canceled_without_final_artifact'] = state.get('902',('',))[0].startswith('CANCELLED') and state.get('903',('',))[0].startswith('CANCELLED')
checks['equivalence_audit_job_completed']=state.get('906',('',))[0]=='COMPLETED'
failed=[k for k,v in checks.items() if not v]
result={'status':'AUDIT_PASS' if not failed else 'AUDIT_FAIL','checks':checks,'checks_passed':len(checks)-len(failed),'checks_total':len(checks),'failed_checks':failed,'scientific_decision':decision.get('decision'),'scientific_result_claimed':False,'manifest_sha256':hashlib.sha256((ROOT/'runs/full/EXPECTED_JOB_MANIFEST.json').read_bytes()).hexdigest(),'runtime_baseline_commit':base['runtime_lock'].get('commit')}
(ROOT/'AUDIT/INDEPENDENT_FINAL_AUDIT.json').write_text(json.dumps(result,indent=2,sort_keys=True))
print(json.dumps(result,indent=2))
if failed: sys.exit(1)
