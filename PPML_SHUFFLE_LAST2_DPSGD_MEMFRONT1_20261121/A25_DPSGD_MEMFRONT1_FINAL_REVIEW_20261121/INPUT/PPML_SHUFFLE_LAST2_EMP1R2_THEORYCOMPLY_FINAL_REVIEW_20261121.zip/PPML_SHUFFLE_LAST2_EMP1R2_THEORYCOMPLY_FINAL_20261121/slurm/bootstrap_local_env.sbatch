#!/usr/bin/env bash
#SBATCH --job-name=scalecert_env
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=1
#SBATCH --mem=2G
#SBATCH --time=00:10:00
#SBATCH --output=logs/envsetup_%j.out
#SBATCH --error=logs/envsetup_%j.err
set -euo pipefail
ROOT="${SLURM_SUBMIT_DIR:-$PWD}"
cd "$ROOT"
ENV=/tmp/ppml_shuffle_last2_emp1_scalecert_venv
rm -rf "$ENV"
mkdir -p /tmp
 tar -xzf "$ROOT/AUDIT/compute_python_env.tar.gz" -C /tmp
"$ENV/bin/python" - <<'PY'
import numpy,scipy,pandas,yaml,matplotlib,pytest,platform
print('python',platform.python_version())
for m in (numpy,scipy,pandas,yaml,matplotlib,pytest): print(m.__name__,getattr(m,'__version__','ok'))
PY
