#!/usr/bin/env bash
#SBATCH --job-name=scalecert_fseq
#SBATCH --partition=cpu
#SBATCH --cpus-per-task=4
#SBATCH --mem=4G
#SBATCH --time=00:20:00
#SBATCH --output=logs/fseq_%j.out
#SBATCH --error=logs/fseq_%j.err
set -euo pipefail
ROOT="${SLURM_SUBMIT_DIR:-$PWD}"; cd "$ROOT"
export PYTHONPATH="$ROOT/src" OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
source .venv/bin/activate
python scripts/run_feldman_baseline.py --input AUDIT/FS_EQUIV/input --out AUDIT/FS_EQUIV/workers_1 --deltas 1e-3,1e-5 --workers 1
python scripts/run_feldman_baseline.py --input AUDIT/FS_EQUIV/input --out AUDIT/FS_EQUIV/workers_4 --deltas 1e-3,1e-5 --workers 4
python - <<'PY'
import json,pathlib,hashlib
root=pathlib.Path('AUDIT/FS_EQUIV')
a=json.loads((root/'workers_1/feldman_shenfeld_baseline.json').read_text())['rows']
b=json.loads((root/'workers_4/feldman_shenfeld_baseline.json').read_text())['rows']
assert a==b,(a,b)
(root/'WORKER_EQUIVALENCE.json').write_text(json.dumps({'status':'PASS','rows':len(a),'values_exact':True,'workers':[1,4]},indent=2,sort_keys=True))
PY
