# SCALECERT execution report

## Terminal status

`STOP_REALISTIC_DP_SGD`

## Execution integrity

- Input archive SHA-256: `cc9d8f11059b7e93e8f5e42d1bd8bde3491bfd0b5bedc9b6a7a185ab45f36ba0`
- Source manifest: 68/68 entries verified before execution.
- Implementation verification: 22 unit tests PASS; exact one-worker/four-worker scientific equivalence PASS; full local 81-job smoke checks PASS.
- Full plan: 336 expected scientific jobs; 210 core + 126 bridges; all 336 outputs are `OK`; zero failed records.
- Feldman–Shenfeld runtime: `MS-FFT-paper` commit `fde83c45bf12c4f7821832c7d5d2ae2841fc0910`; 144/144 queries completed without failure.
- Independent final audit: `AUDIT_PASS`, 23/23 checks.
- No GPU stage was run.

## Scientific decision

All continuous-theory and numerical validation gates pass, including main scaling, convergence, theory certificates, at-most-k user adjacency, memory collapse, multi-epoch behavior, stress/finite-amplitude controls, SGLD bridge, DP-SGD numerical convergence, and the matched Feldman–Shenfeld lower-bound gate. The frozen DP-SGD growth gate fails, so the correct terminal result is `STOP_REALISTIC_DP_SGD`, not a numerical or implementation halt.

The required `k=2, eta=0.1, z=2` and `z=4` fits have stored symmetric-TV exponent betas approximately `-0.7519` and `-0.5056`; both fail the frozen `beta > 0.55` criterion. The `z=4` line also has `R² ≈ 0.9047`, below `0.95`. Transcript chi-square fits are near exponent 1. The successful accountant comparison does not rescue this failed DP-SGD scaling gate.

This validates the frozen continuous hidden-state scaling theory and numerical implementation, but it does not authorize realistic user-level DP-SGD ML under the pre-registered bridge criteria.

## Progress and resources

See `RUN_PROGRESS.jsonl`, `runs/full/JOB_LEDGER.json`, `runs/full/CPU_ENVIRONMENT.json`, and the SLURM stdout/stderr logs. Core/bridge stages used 32 and 16 CPUs concurrently. The final accountant run used four process workers with one numerical-library thread each; its one-worker/four-worker result equivalence audit passed.

## Deviations

Only execution plumbing changed: the Feldman–Shenfeld query loop was made process-parallel and gained per-query progress logs after the original serial wrapper was observed to use one of four allocated CPUs. The scientific queries and comparison values were unchanged. See `AUDIT/EXECUTION_ADAPTATIONS.md` and `AUDIT/INPUT_MANIFEST_RECONCILIATION.json`.
