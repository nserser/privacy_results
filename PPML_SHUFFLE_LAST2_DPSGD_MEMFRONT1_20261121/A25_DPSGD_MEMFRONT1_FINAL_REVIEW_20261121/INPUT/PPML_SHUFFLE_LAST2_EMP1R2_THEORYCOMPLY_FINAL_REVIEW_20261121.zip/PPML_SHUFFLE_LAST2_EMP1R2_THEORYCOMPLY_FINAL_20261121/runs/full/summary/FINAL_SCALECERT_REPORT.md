# SCALECERT Theory-Compliant Aggregate Report

**Decision:** `STOP_REALISTIC_DP_SGD`
**Reason:** continuous theory is certified but prespecified user-level DP-SGD lines do not robustly show a growing gap

## Gate summary
- expected_manifest: PASS
- convergence: PASS
- main_scaling: PASS
- theory_certificates: PASS
- k_packet: PASS
- at_most_k_adjacency: PASS
- collision_stress: PASS
- finite_amplitude: PASS
- known_vs_hidden_support: PASS
- no_forgetting: PASS
- memory_collapse: PASS
- metastability: PASS
- multi_epoch: PASS
- sgld_bridge: PASS
- dpsgd_numerical_convergence: PASS
- dpsgd_bridge: FAIL
- feldman_shenfeld: PASS

See `checks.json`, `scaling_fits.csv`, `all_results.csv`, and the exact expected-job manifest for inspectable evidence.
